def read_employee():
    file = open("employee_file.txt",'r')  # open the file in read mode
    
    line = file.readlines() 
    print(line)
    
    file.close()

    return line

def write_employee(emp_name, designation, salary):
    id = 1
    with open("employee_file.txt", "r") as file:
        lines = file.readlines() 
    
    lines_len = len(lines)
    if lines_len == 0:
        id = 1
    else:
        id = int(lines[lines_len-1].split(',')[0])+1

    file = open("employee_file.txt",'a')  # open the file

    emp_record = f"{id},{emp_name},{designation},{salary}\n"  # specify the format inwhcih data will be added into file
    file.write(emp_record)
    
    file.close()

def upd_employee(id,new_data):
    with open("employee_file.txt", "r") as file:
        lines = file.readlines() 
    
    with open("employee_file.txt", "w") as file:
        for line in lines:
            if line.strip().startswith(id):
                file.write(line.replace('\n',',')+new_data+'\n')
            else:
                file.write(line)
    
    file.close()

def del_employee(id):
    with open("employee_file.txt", "r") as file:
        lines = file.readlines() 
    
    with open("employee_file.txt", "w") as file:
        for line in lines:
            if not line.strip().startswith(id):
                file.write(line)
    
    file.close()