from flask import Flask,render_template,request
from file_handling import write_employee, read_employee, upd_employee, del_employee

app = Flask(__name__)  # creates an instance of the Flask class

@app.route("/home")  # defines a route for the root URL 
def home():
    return render_template("employee.html")


@app.route("/add_employee",methods=["POST"])
def add_employee():
    # we will pick the values from the form and store into variables
    emp_name = request.form["emp_name"]
    designation = request.form["designation"]
    salary = float(request.form["salary"])

    write_employee(emp_name, designation, salary)
    
    return "Employee Added successfully !!"


@app.route("/view_employee")
def view_employee():
    return read_employee()

@app.route("/update_employee",methods=["POST"])
def update_employee():
    emp_id = request.form["emp_id"]
    new_data = request.form["new_data"]

    upd_employee(emp_id,new_data)
    
    return "Employee Updated successfully !!" 

@app.route("/delete_employee",methods=["POST"])
def delete_employee():
    emp_id = request.form["emp_id"]

    del_employee(emp_id)

    return "Employee Deleted successfully !!" 

if __name__ == "__main__":
    app.run(debug=True)     # this will start my web server